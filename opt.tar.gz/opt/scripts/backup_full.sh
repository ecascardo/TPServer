#!/bin/bash

function show_help {
    echo "Uso: $0 [opciones] origen destino"
    echo "Opciones:"
    echo "  -help        Muestra esta ayuda"
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
}

if [[ "$1" == "-help" ]]; then
    show_help
    exit 0
fi

if [ "$#" -ne 2 ]; then
    echo "Número incorrecto de argumentos."
    show_help
    exit 1
fi

ORIGEN=$1
DESTINO=$2

if [ ! -d "$ORIGEN" ]; then
    echo "El directorio de origen no existe: $ORIGEN"
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "El directorio de destino no existe: $DESTINO"
    exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE_ARCHIVO=$(basename "$ORIGEN")_bkp_$FECHA.tar.gz

tar -czf "$DESTINO/$NOMBRE_ARCHIVO" -C "$ORIGEN" .

echo "Backup realizado: $DESTINO/$NOMBRE_ARCHIVO"

